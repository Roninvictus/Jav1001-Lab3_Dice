//Dice game simulation
import kotlin.random.Random

class DiceGame {
    fun run() {
        println("Creating the default d6...")
        val d6 = Die()
        println("Create a d20...")
        val d20 = Die(20)
        println("Creating a die (a special d10)...")
        val percentile = Die(10, "Percentile")

        //Print results before die roll
        println("The current side up for ${d6.name} is ${d6.currentSideUp}")
        println("The current side up for ${d20.name} is ${d20.currentSideUp}")
        println("The current side up for ${percentile.name} is ${percentile.currentSideUp}\n")

        println("Testing the roll method\n")

        //Results after die roll
        println("Rolling the d6...")
        d6.roll()
        println("The new value is ${d6.currentSideUp}\n")

        println("Rolling the d20...")
        d20.roll() // fixed typo d6.roll() to d20.roll()
        println("The new value is ${d20.currentSideUp}\n")

        println("Rolling the percentile...")
        percentile.roll() // fixed typo d6.roll() to percentile.roll()
        println("The new value is ${percentile.currentSideUp}\n")

        //Set die to show highest value
        println("Setting d20 to show highest value 20...") //number of sides = highest value
        d20.currentSideUp = d20.numOfSides
        println("The Side up is now ${d20.currentSideUp}.\n")

        println("Creating 5 d6..")//To create 5 dies of six sides
        val dice = Array(5) { Die(6) }

        var numOfRolls = 0
        do {
            for (i in 0 until 5) {
                dice[i].roll()
                println("The current side up for ${dice[i].name} is ${dice[i].currentSideUp}")
            }
            numOfRolls++ //increment till loop exit
        } while (!dice.all { it.currentSideUp == dice[0].currentSideUp })

        println("YAHTZEE! It took $numOfRolls rolls")
    }
}

fun main() {
    DiceGame().run()
}



