//Victor Sokowocin Yusuf
//Student ID: A00254959
//JAV1001-Lab3
//Dice game simulator

import kotlin.random.Random

class Die {
    //val assignments for type and sides, but var for side up
    var name: String = "d6"
    //total number of sides
    var numOfSides: Int = 6
    //side of die facing up
    var currentSideUp: Int = 1

    constructor() { //default constructor with 0 argument
        name = "d6"
        numOfSides = 6
        roll()
    }

    //constructor with first argument
    constructor(numOfSides: Int) {
        this.numOfSides = numOfSides
        this.name = "d$numOfSides"
        roll()
    }

    //constructor with 2nd argument
    constructor(numOfSides: Int, name: String) {
        this.numOfSides = numOfSides
        this.name = name
        roll()
    }

    fun roll() { //roll function to generate random values
        currentSideUp = Random.nextInt(1, numOfSides + 1)
    }
}
